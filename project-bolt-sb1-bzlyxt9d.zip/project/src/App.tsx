import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, Link } from 'react-router-dom';
import { UserCircle, LayoutGrid } from 'lucide-react';
import { supabase } from './lib/supabase';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import LeadCapture from './components/LeadCapture';
import BrandingSetup from './components/BrandingSetup';
import Profile from './components/Profile';
import FortuneCookie from './components/FortuneCookie';

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setIsAuthenticated(!!session);
    });

    return () => subscription.unsubscribe();
  }, []);

  if (isAuthenticated === null) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
        <nav className="bg-primary shadow-lg">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <FortuneCookie className="h-8 w-8 text-white" />
                <span className="ml-2 text-xl font-semibold text-white">Fortune Cookie Leads</span>
              </div>
              {isAuthenticated && (
                <div className="flex items-center space-x-6">
                  <Link
                    to="/dashboard"
                    className="text-white hover:text-gray-200 transition-colors flex items-center"
                  >
                    <LayoutGrid className="h-5 w-5 mr-2" />
                    <span>Campaigns</span>
                  </Link>
                  <Link
                    to="/profile"
                    className="text-white hover:text-gray-200 transition-colors flex items-center"
                  >
                    <UserCircle className="h-5 w-5 mr-2" />
                    <span>My Account</span>
                  </Link>
                  <button
                    onClick={() => supabase.auth.signOut()}
                    className="text-white hover:text-gray-200 transition-colors"
                  >
                    Sign Out
                  </button>
                </div>
              )}
            </div>
          </div>
        </nav>

        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Routes>
            <Route
              path="/"
              element={
                isAuthenticated ? (
                  <Navigate to="/dashboard" replace />
                ) : (
                  <Login />
                )
              }
            />
            <Route
              path="/dashboard"
              element={
                isAuthenticated ? (
                  <Dashboard />
                ) : (
                  <Navigate to="/" replace />
                )
              }
            />
            <Route
              path="/branding-setup"
              element={
                isAuthenticated ? (
                  <BrandingSetup />
                ) : (
                  <Navigate to="/" replace />
                )
              }
            />
            <Route
              path="/profile"
              element={
                isAuthenticated ? (
                  <Profile />
                ) : (
                  <Navigate to="/" replace />
                )
              }
            />
            <Route path="/capture/:campaignId" element={<LeadCapture />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}