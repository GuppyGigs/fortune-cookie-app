export type SubscriptionTier = 'free' | 'pro' | 'enterprise';

export interface Campaign {
  id: string;
  title: string;
  niche: string;
  welcomeMessage: string;
  leads: Lead[];
  branding?: {
    primaryColor?: string;
    logo?: string;
  };
}

export interface Lead {
  name: string;
  email: string;
  fortune: string;
  timestamp: string;
  campaignId: string;
}

export interface User {
  id: string;
  username: string;
  email: string;
  subscriptionTier: SubscriptionTier;
  campaigns: Campaign[];
  activeCampaignId?: string;
  branding?: {
    primaryColor?: string;
    logo?: string;
  };
}