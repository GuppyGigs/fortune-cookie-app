// This file is now deprecated as we're using Supabase
// Keeping the generateFortune function as it's still used
export const generateFortune = (niche: string): string => {
  const fortunes = {
    business: [
      "A golden opportunity will present itself in your next business venture",
      "Your innovative thinking will lead to unexpected success",
      "A valuable partnership is on the horizon",
      "Your leadership skills will shine in an upcoming challenge"
    ],
    health: [
      "Your commitment to wellness will bring unexpected rewards",
      "A new health practice will transform your daily routine",
      "Balance in all things will lead to your greatest vitality",
      "Your dedication to self-care will inspire others"
    ],
    default: [
      "Your path is uniquely yours - embrace the journey ahead",
      "A moment of insight will change your perspective forever",
      "The wisdom you seek is already within you",
      "Your authentic self will attract authentic opportunities"
    ]
  };

  const nicheList = fortunes[niche as keyof typeof fortunes] || fortunes.default;
  const basePhrase = nicheList[Math.floor(Math.random() * nicheList.length)];
  
  const timeModifiers = [
    "when the moon is full",
    "as spring approaches",
    "before the year ends",
    "in the coming weeks",
    "when you least expect it"
  ];
  
  const modifier = timeModifiers[Math.floor(Math.random() * timeModifiers.length)];
  
  return `${basePhrase} ${modifier}`;
};