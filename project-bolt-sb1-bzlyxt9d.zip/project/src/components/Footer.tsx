import React from 'react';
import { ExternalLink } from 'lucide-react';
import guppyLogo from '../assets/guppy logo.png';

interface FooterProps {
  className?: string;
}

export default function Footer({ className = '' }: FooterProps) {
  return (
    <footer className={`py-8 ${className}`}>
      <a
        href="https://guppygigs.com/fortunecookieleads/"
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center justify-center gap-2 text-base hover:opacity-80 transition-opacity"
      >
        <span className="text-[#03376e]">Powered by</span>
        <img
          src={guppyLogo}
          alt="Guppy Gigs"
          className="h-12 w-auto object-contain"
          onError={(e) => {
            const target = e.currentTarget;
            // Replace with text if image fails to load
            target.style.display = 'none';
            const textSpan = document.createElement('span');
            textSpan.className = 'text-[#03376e] font-semibold';
            textSpan.textContent = 'Guppy Gigs';
            target.parentNode?.appendChild(textSpan);
          }}
        />
      </a>
    </footer>
  );
}