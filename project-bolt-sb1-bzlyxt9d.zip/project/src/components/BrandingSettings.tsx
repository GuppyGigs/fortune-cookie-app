import React, { useState, useCallback } from 'react';
import { Palette, Upload } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Database } from '../lib/database.types';

type Profile = Database['public']['Tables']['profiles']['Row'];

interface BrandingSettingsProps {
  profile: Profile;
  onUpdate: () => void;
}

export default function BrandingSettings({ profile, onUpdate }: BrandingSettingsProps) {
  const [primaryColor, setPrimaryColor] = useState(
    (profile.branding as any)?.primaryColor || '#03376e'
  );
  const [logo, setLogo] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState((profile.branding as any)?.logo || '');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const handleLogoChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Preview the selected image
    const reader = new FileReader();
    reader.onloadend = () => {
      setLogoPreview(reader.result as string);
    };
    reader.readAsDataURL(file);
    setLogo(file);
  }, []);

  const uploadLogo = async (file: File): Promise<string> => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Not authenticated');

    const fileExt = file.name.split('.').pop();
    const fileName = `${user.id}-${Math.random()}.${fileExt}`;
    const filePath = `logos/${fileName}`;

    const { error: uploadError } = await supabase.storage
      .from('brand-assets')
      .upload(filePath, file);

    if (uploadError) throw uploadError;

    const { data: { publicUrl } } = supabase.storage
      .from('brand-assets')
      .getPublicUrl(filePath);

    return publicUrl;
  };

  const handleSave = async () => {
    try {
      setSaving(true);
      setError('');

      let logoUrl = (profile.branding as any)?.logo || '';
      if (logo) {
        logoUrl = await uploadLogo(logo);
      }

      const { error: updateError } = await supabase
        .from('profiles')
        .update({
          branding: {
            primaryColor,
            logo: logoUrl
          }
        })
        .eq('id', profile.id);

      if (updateError) throw updateError;
      
      // Call the onUpdate callback to refresh the profile data
      onUpdate();
    } catch (err) {
      console.error('Error saving branding:', err);
      setError('Failed to save branding settings');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden">
      <div className="p-8">
        <div className="flex items-center mb-6">
          <Palette className="w-5 h-5 text-primary mr-2" />
          <h2 className="text-xl font-semibold text-gray-900">Branding Settings</h2>
        </div>

        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Brand Color
            </label>
            <div className="flex items-center space-x-2">
              <input
                type="color"
                value={primaryColor}
                onChange={(e) => setPrimaryColor(e.target.value)}
                className="h-10 w-20"
              />
              <input
                type="text"
                value={primaryColor}
                onChange={(e) => setPrimaryColor(e.target.value)}
                className="flex-1 rounded-xl border-gray-300 shadow-sm focus:border-primary focus:ring-primary"
                placeholder="#000000"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Logo
            </label>
            <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-xl hover:border-gray-400 transition-colors">
              <div className="space-y-1 text-center">
                {logoPreview ? (
                  <img
                    src={logoPreview}
                    alt="Logo preview"
                    className="mx-auto h-32 w-auto object-contain"
                  />
                ) : (
                  <Upload className="mx-auto h-12 w-12 text-gray-400" />
                )}
                <div className="flex text-sm text-gray-600">
                  <label className="relative cursor-pointer rounded-md font-medium text-primary hover:text-primary-light focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-primary">
                    <span>Upload a file</span>
                    <input
                      type="file"
                      className="sr-only"
                      accept="image/*"
                      onChange={handleLogoChange}
                    />
                  </label>
                  <p className="pl-1">or drag and drop</p>
                </div>
                <p className="text-xs text-gray-500">
                  PNG, JPG, GIF up to 10MB
                </p>
              </div>
            </div>
          </div>

          {error && (
            <div className="text-red-600 text-sm">{error}</div>
          )}

          <div className="flex justify-end">
            <button
              onClick={handleSave}
              disabled={saving}
              className="px-4 py-2 bg-primary text-white rounded-xl hover:bg-primary-light disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-sm"
            >
              {saving ? 'Saving...' : 'Save Changes'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}