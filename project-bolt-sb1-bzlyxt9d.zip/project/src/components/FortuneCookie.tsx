import React from 'react';

export default function FortuneCookie({ className = '', ...props }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.75"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      {...props}
    >
      {/* Main curved body of the fortune cookie */}
      <path d="M6 14c2-2 12-2 14-4" />
      {/* Top fold creating the characteristic shape */}
      <path d="M20 10c-2-4-10-4-14-2" />
      {/* Bottom curve completing the shape */}
      <path d="M6 14c3 3 11 1 14-4" />
      {/* Additional detail lines */}
      <path d="M8 13c2-1.5 8-1.5 10-3" />
      <path d="M18 9c-1.5-3-7-3-10-1.5" />
    </svg>
  );
}