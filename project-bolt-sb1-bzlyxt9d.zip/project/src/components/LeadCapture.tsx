import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Cookie, Loader2, Sparkles } from 'lucide-react';
import validator from 'validator';
import { supabase } from '../lib/supabase';
import type { Database } from '../lib/database.types';
import Footer from './Footer';

type Campaign = Database['public']['Tables']['campaigns']['Row'] & {
  profiles?: {
    branding: any;
  };
};

export default function LeadCapture() {
  const { campaignId } = useParams();
  const [campaign, setCampaign] = useState<Campaign | null>(null);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [fortune, setFortune] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [generating, setGenerating] = useState(false);

  useEffect(() => {
    const fetchCampaign = async () => {
      try {
        const { data, error } = await supabase
          .from('campaigns')
          .select(`
            *,
            profiles:user_id (
              branding
            )
          `)
          .eq('id', campaignId)
          .single();

        if (error) throw error;
        setCampaign(data);

        // Apply branding if available
        const branding = data.branding || (data.profiles as any)?.branding;
        if (branding?.primaryColor) {
          document.documentElement.style.setProperty('--color-primary', branding.primaryColor);
          document.documentElement.style.setProperty('--color-primary-light', branding.primaryColor + '99');
        }
      } catch (err) {
        console.error('Error fetching campaign:', err);
        setError('Campaign not found');
      } finally {
        setLoading(false);
      }
    };

    if (campaignId) {
      fetchCampaign();
    }
  }, [campaignId]);

  const generateFortune = async (niche: string): Promise<string> => {
    try {
      setGenerating(true);
      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/generate-fortune`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ niche }),
      });

      if (!response.ok) {
        throw new Error('Failed to generate fortune');
      }

      const data = await response.json();
      return data.fortune;
    } catch (error) {
      console.error('Error generating fortune:', error);
      return `Your journey in ${niche} will bring unexpected rewards in the coming weeks.`;
    } finally {
      setGenerating(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSubmitting(true);
    
    try {
      if (!validator.isEmail(email)) {
        throw new Error('Please enter a valid email address');
      }

      if (!campaign) {
        throw new Error('Campaign not found');
      }

      // Generate the personalized fortune
      const newFortune = await generateFortune(campaign.niche);
      
      // Save the lead with the generated fortune
      const { error: leadError } = await supabase
        .from('leads')
        .insert({
          campaign_id: campaignId,
          name,
          email,
          fortune: newFortune
        });

      if (leadError) throw leadError;
      
      // Display the fortune
      setFortune(newFortune);
    } catch (err) {
      console.error('Error saving lead:', err);
      setError(err instanceof Error ? err.message : 'An error occurred. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!campaign) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center text-gray-600">
          <p className="text-xl font-semibold">Campaign not found</p>
          <p className="mt-2">This campaign may have been deleted or is no longer available.</p>
        </div>
      </div>
    );
  }

  const branding = campaign.branding || (campaign.profiles as any)?.branding;

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="flex-grow flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-xl shadow-xl overflow-hidden">
          <div className="p-8">
            <div className="text-center mb-8">
              <div className="mb-4">
                {branding?.logo ? (
                  <img
                    src={branding.logo}
                    alt="Campaign Logo"
                    className="h-12 w-auto mx-auto object-contain"
                    onError={(e) => {
                      const target = e.currentTarget;
                      target.style.display = 'none';
                      const cookieIcon = document.createElement('div');
                      cookieIcon.innerHTML = `<svg class="h-12 w-12 text-primary mx-auto" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M6 14c2-2 12-2 14-4"/><path d="M20 10c-2-4-10-4-14-2"/><path d="M6 14c3 3 11 1 14-4"/><path d="M8 13c2-1.5 8-1.5 10-3"/><path d="M18 9c-1.5-3-7-3-10-1.5"/></svg>`;
                      target.parentNode?.insertBefore(cookieIcon.firstChild!, target);
                    }}
                  />
                ) : (
                  <Cookie className="h-12 w-12 text-primary mx-auto" />
                )}
              </div>
              <h2 className="text-2xl font-bold text-gray-900">Your Fortune Awaits</h2>
              {campaign.welcome_message && (
                <p className="mt-2 text-gray-600">{campaign.welcome_message}</p>
              )}
            </div>

            {!fortune ? (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                    Your Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    required
                    className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-primary focus:ring-primary"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                    Email Address
                  </label>
                  <input
                    type="email"
                    id="email"
                    required
                    className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-primary focus:ring-primary"
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      setError('');
                    }}
                  />
                  {error && <p className="mt-1 text-sm text-red-600">{error}</p>}
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary-light focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {submitting ? (
                    <div className="flex items-center justify-center">
                      <Loader2 className="w-5 h-5 animate-spin mr-2" />
                      <span>Generating Fortune...</span>
                    </div>
                  ) : (
                    'Reveal Your Fortune'
                  )}
                </button>
              </form>
            ) : (
              <div className="text-center">
                <div className="relative">
                  <div className="absolute -inset-1">
                    <div className="w-full h-full mx-auto rotate-180 opacity-30 blur-lg filter bg-gradient-to-r from-primary via-purple-500 to-pink-500"></div>
                  </div>
                  <div className="relative bg-white rounded-lg p-6 border border-primary/10">
                    <Sparkles className="w-6 h-6 text-primary mx-auto mb-3" />
                    <p className="text-lg text-gray-900 font-medium italic">{fortune}</p>
                  </div>
                </div>
                <p className="mt-6 text-sm text-gray-600">
                  Thank you for participating! Your fortune has been revealed.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}