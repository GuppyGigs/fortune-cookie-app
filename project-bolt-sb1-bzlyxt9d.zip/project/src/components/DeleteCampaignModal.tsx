import React from 'react';
import { AlertTriangle, X } from 'lucide-react';

interface DeleteCampaignModalProps {
  campaignTitle: string;
  onConfirm: () => void;
  onCancel: () => void;
}

export default function DeleteCampaignModal({ campaignTitle, onConfirm, onCancel }: DeleteCampaignModalProps) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-md">
        <div className="p-6">
          <div className="flex justify-between items-start mb-4">
            <div className="flex items-center">
              <AlertTriangle className="w-6 h-6 text-red-500 mr-2" />
              <h3 className="text-lg font-semibold text-gray-900">Delete Campaign</h3>
            </div>
            <button
              onClick={onCancel}
              className="text-gray-400 hover:text-gray-500 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="mb-6">
            <p className="text-gray-600">
              Are you sure you want to delete <span className="font-semibold">{campaignTitle}</span>? This action cannot be undone and all associated leads will be permanently deleted.
            </p>
          </div>

          <div className="flex justify-end space-x-3">
            <button
              onClick={onCancel}
              className="px-4 py-2 text-gray-700 hover:bg-gray-50 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={onConfirm}
              className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
            >
              Delete Campaign
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}