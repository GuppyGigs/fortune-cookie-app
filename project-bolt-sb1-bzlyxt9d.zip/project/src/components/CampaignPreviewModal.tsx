import React from 'react';
import QRCode from 'react-qr-code';
import { X, Cookie } from 'lucide-react';
import { APP_URL } from '../lib/constants';
import type { Database } from '../lib/database.types';
import Footer from './Footer';

type Campaign = Database['public']['Tables']['campaigns']['Row'] & {
  profiles?: {
    branding: any;
  };
};

interface CampaignPreviewModalProps {
  campaign: Campaign;
  onClose: () => void;
}

export default function CampaignPreviewModal({ campaign, onClose }: CampaignPreviewModalProps) {
  const branding = campaign.branding || campaign.profiles?.branding;
  const primaryColor = branding?.primaryColor || '#03376e';
  const logo = branding?.logo || null;

  const getCaptureUrl = (campaignId: string) => {
    return `${APP_URL}/capture/${campaignId}`;
  };
  
// Temporary debug log to verify the QR code URL
console.log("QR Code URL:", getCaptureUrl(campaign.id));
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex justify-end mb-2">
            <button
              onClick={onClose}
              className="text-gray-500 hover:text-gray-700 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          <div 
            className="border-[3px] rounded-xl overflow-hidden"
            style={{ borderColor: primaryColor }}
          >
            <div className="max-w-lg mx-auto p-6">
              <div className="mb-6 flex justify-center">
                {logo ? (
                  <img
                    src={logo}
                    alt="Brand Logo"
                    className="h-12 w-auto object-contain"
                    onError={(e) => {
                      const target = e.currentTarget;
                      target.style.display = 'none';
                      const cookieIcon = document.createElement('div');
                      cookieIcon.innerHTML = `<svg class="h-12 w-12" viewBox="0 0 24 24" fill="none" stroke="${primaryColor}" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M6 14c2-2 12-2 14-4"/><path d="M20 10c-2-4-10-4-14-2"/><path d="M6 14c3 3 11 1 14-4"/><path d="M8 13c2-1.5 8-1.5 10-3"/><path d="M18 9c-1.5-3-7-3-10-1.5"/></svg>`;
                      target.parentNode?.insertBefore(cookieIcon.firstChild!, target);
                    }}
                  />
                ) : (
                  <Cookie className="h-12 w-12" style={{ color: primaryColor }} />
                )}
              </div>

              {campaign.welcome_message && (
                <p className="text-lg mb-6 text-center text-gray-900 max-w-md mx-auto">
                  {campaign.welcome_message}
                </p>
              )}

              <div className="flex justify-center mb-2">
                <div 
                  className="p-3 rounded-xl"
                  style={{ backgroundColor: `${primaryColor}10` }}
                >
                  <QRCode
                    value={getCaptureUrl(campaign.id)}
                    size={200}
                    fgColor={primaryColor}
                    level="H"
                  />
                </div>
              </div>

              <div className="-mb-4">
                <Footer className="py-2" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}