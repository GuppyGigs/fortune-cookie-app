import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import QRCode from 'react-qr-code';
import { Download, Plus, Loader2, ArrowRight, Target, Users, MessageSquare, Trash2 } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { APP_URL } from '../lib/constants';
import type { Database } from '../lib/database.types';
import Footer from './Footer';
import CampaignPreviewModal from './CampaignPreviewModal';
import DeleteCampaignModal from './DeleteCampaignModal';

type Campaign = Database['public']['Tables']['campaigns']['Row'] & {
  branding?: any;
};

type Profile = Database['public']['Tables']['profiles']['Row'];

export default function Dashboard() {
  const [user, setUser] = useState<Profile | null>(null);
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [showNewCampaign, setShowNewCampaign] = useState(false);
  const [title, setTitle] = useState('');
  const [niche, setNiche] = useState('');
  const [welcomeMessage, setWelcomeMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [previewCampaign, setPreviewCampaign] = useState<Campaign | null>(null);
  const [campaignToDelete, setCampaignToDelete] = useState<Campaign | null>(null);
  const navigate = useNavigate();

  const getCaptureUrl = (campaignId: string) => {
    return `${APP_URL}/capture/${campaignId}`;
  };

  const fetchUserAndCampaigns = async () => {
    try {
      const { data: { user: authUser } } = await supabase.auth.getUser();
      if (!authUser) {
        navigate('/');
        return;
      }

      const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', authUser.id)
        .maybeSingle();

      if (!profile || !profile.onboarding_completed) {
        navigate('/branding-setup');
        return;
      }

      const { data: campaignsData, error: campaignsError } = await supabase
        .from('campaigns')
        .select('*')
        .eq('user_id', authUser.id)
        .order('created_at', { ascending: false });

      if (campaignsError) throw campaignsError;

      const enrichedCampaigns = campaignsData?.map(campaign => ({
        ...campaign,
        branding: profile.branding
      })) || [];

      setUser(profile);
      setCampaigns(enrichedCampaigns);
    } catch (err) {
      console.error('Error fetching data:', err);
      setError('Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUserAndCampaigns();
  }, [navigate]);

  const createCampaign = async () => {
    if (!user) return;

    try {
      if (campaigns.length >= 2) {
        setError('You have reached the maximum limit of 2 campaigns.');
        return;
      }

      const { data: { user: authUser } } = await supabase.auth.getUser();
      if (!authUser) throw new Error('Not authenticated');

      const { data: campaign, error: campaignError } = await supabase
        .from('campaigns')
        .insert({
          user_id: authUser.id,
          title,
          niche,
          welcome_message: welcomeMessage,
          branding: user.branding
        })
        .select()
        .single();

      if (campaignError) {
        if (campaignError.message.includes('Campaign limit reached')) {
          throw new Error('You have reached the maximum limit of 2 campaigns.');
        }
        throw campaignError;
      }

      if (campaigns.length === 0) {
        const { error: updateError } = await supabase
          .from('profiles')
          .update({ active_campaign_id: campaign.id })
          .eq('id', authUser.id);

        if (updateError) throw updateError;
      }

      const enrichedCampaign = {
        ...campaign,
        branding: user.branding
      };

      setCampaigns([enrichedCampaign, ...campaigns]);
      setShowNewCampaign(false);
      setTitle('');
      setNiche('');
      setWelcomeMessage('');
      setError('');
    } catch (err) {
      console.error('Error creating campaign:', err);
      setError(err instanceof Error ? err.message : 'Failed to create campaign');
      setShowNewCampaign(false);
    }
  };

  const setActiveCampaign = async (campaignId: string) => {
    try {
      const { error: updateError } = await supabase
        .from('profiles')
        .update({ active_campaign_id: campaignId })
        .eq('id', user?.id);

      if (updateError) throw updateError;

      setUser(prev => prev ? { ...prev, active_campaign_id: campaignId } : null);
      
      const campaign = campaigns.find(c => c.id === campaignId);
      if (campaign) {
        setPreviewCampaign(campaign);
      }
    } catch (err) {
      console.error('Error setting active campaign:', err);
      setError('Failed to update active campaign');
    }
  };

  const deleteCampaign = async (campaign: Campaign) => {
    try {
      const { error: deleteError } = await supabase
        .from('campaigns')
        .delete()
        .eq('id', campaign.id);

      if (deleteError) throw deleteError;

      if (campaign.id === user?.active_campaign_id) {
        const { error: updateError } = await supabase
          .from('profiles')
          .update({ active_campaign_id: null })
          .eq('id', user?.id);

        if (updateError) throw updateError;
        setUser(prev => prev ? { ...prev, active_campaign_id: null } : null);
      }

      setCampaigns(campaigns.filter(c => c.id !== campaign.id));
      setCampaignToDelete(null);
    } catch (err) {
      console.error('Error deleting campaign:', err);
      setError('Failed to delete campaign');
    }
  };

  const downloadLeads = async (campaignId: string) => {
    try {
      const { data: leads, error } = await supabase
        .from('leads')
        .select('*')
        .eq('campaign_id', campaignId);

      if (error) throw error;

      const csvContent = [
        ['Name', 'Email', 'Fortune', 'Created At'].join(','),
        ...leads.map(lead => 
          [lead.name, lead.email, lead.fortune, lead.created_at].join(',')
        )
      ].join('\n');

      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `leads-${campaignId}.csv`;
      a.click();
      window.URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Error downloading leads:', err);
      setError('Failed to download leads');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Campaigns</h1>
          <p className="text-sm text-gray-500 mt-1">
            Manage your lead generation campaigns ({campaigns.length}/2 campaigns)
          </p>
        </div>

        {campaigns.length === 0 && (
          <div className="bg-gradient-to-br from-primary/5 to-primary/10 backdrop-blur-xl rounded-2xl p-8 border border-primary/10">
            <div className="flex items-start space-x-4">
              <div className="flex-shrink-0 bg-primary/10 rounded-full p-2">
                <ArrowRight className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  Welcome to Fortune Cookie Leads!
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  Start by creating your first campaign. Each campaign generates a unique QR code 
                  that you can share with your audience. When scanned, they'll receive a personalized 
                  fortune and you'll capture their contact information.
                </p>
              </div>
            </div>
          </div>
        )}

        <div className="flex justify-end">
          {campaigns.length >= 2 ? (
            <button
              disabled
              className="flex items-center px-4 py-2 bg-gray-100 text-gray-500 rounded-xl cursor-not-allowed"
            >
              <Plus className="w-4 h-4 mr-2" />
              Maximum Campaigns Created
            </button>
          ) : (
            <button
              onClick={() => setShowNewCampaign(true)}
              className="flex items-center px-4 py-2 bg-primary text-white rounded-xl hover:bg-primary-light transition-all shadow-sm"
            >
              <Plus className="w-4 h-4 mr-2" />
              New Campaign
            </button>
          )}
        </div>

        {error && (
          <div className="bg-red-50 border-l-4 border-red-400 p-4 rounded-lg">
            <div className="flex">
              <div className="flex-shrink-0">
                <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                </svg>
              </div>
              <div className="ml-3">
                <p className="text-sm text-red-700">{error}</p>
              </div>
            </div>
          </div>
        )}

        {showNewCampaign && (
          <div className="space-y-4">
            <div className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden">
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <Target className="w-5 h-5 text-primary mr-2" />
                  <h2 className="text-xl font-semibold text-gray-900">Campaign Details</h2>
                </div>
                <div>
                  <label className="block text-lg font-medium text-gray-700 mb-2">
                    Campaign Title
                  </label>
                  <p className="text-base text-gray-600 mb-3">
                    This is for internal use only to help you identify your campaigns
                  </p>
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="block w-full border-2 focus:ring-2 focus:ring-offset-0 focus:ring-primary/20 focus:border-primary transition-colors"
                    placeholder="Leadership Inservice Lunch & Learn"
                  />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden">
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <Users className="w-5 h-5 text-primary mr-2" />
                  <h2 className="text-xl font-semibold text-gray-900">Audience Details</h2>
                </div>
                <div>
                  <label className="block text-lg font-medium text-gray-700 mb-2">
                    Target Audience/Niche
                  </label>
                  <p className="text-base text-gray-600 mb-3">
                    Add detailed information about your audience to help customize their fortunes. Include demographics, roles, and aspirations.
                  </p>
                  <div className="space-y-4 mb-4">
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <p className="text-base text-gray-600">
                        <strong>Example 1:</strong> Professional case managers overseeing patient accounts and care in rehab hospitals, ages 30-60. They are dedicated to providing excellent patient care while managing complex cases.
                      </p>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <p className="text-base text-gray-600">
                        <strong>Example 2:</strong> Adults, ages 25-70, who are in leadership roles in their communities and workplaces. They aspire to be the best leaders they can be and know that growing in their emotional intelligence is a key to make that happen.
                      </p>
                    </div>
                  </div>
                  <textarea
                    value={niche}
                    onChange={(e) => setNiche(e.target.value)}
                    className="block w-full border-2 focus:ring-2 focus:ring-offset-0 focus:ring-primary/20 focus:border-primary transition-colors"
                    rows={6}
                  />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden">
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <MessageSquare className="w-5 h-5 text-primary mr-2" />
                  <h2 className="text-xl font-semibold text-gray-900">Welcome Message</h2>
                </div>
                <div>
                  <label className="block text-lg font-medium text-gray-700 mb-2">
                    Customize Your Welcome Message
                  </label>
                  <p className="text-base text-gray-600 mb-3">
                    Create a welcoming message that will appear above the QR code. Make it personal and relevant to your audience.
                  </p>
                  <div className="space-y-4 mb-4">
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <p className="text-base text-gray-600">
                        <strong>Example 1:</strong> Thank you for the ways you serve your patients! Enter your name and email address to receive your Case Manager Fortune of the day!
                      </p>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <p className="text-base text-gray-600">
                        <strong>Example 2:</strong> What's as fun as being empowered by your emotions? Getting your Empowered by Emotions Fortune! Submit your name and email address to get yours now!
                      </p>
                    </div>
                  </div>
                  <textarea
                    value={welcomeMessage}
                    onChange={(e) => setWelcomeMessage(e.target.value)}
                    className="block w-full border-2 focus:ring-2 focus:ring-offset-0 focus:ring-primary/20 focus:border-primary transition-colors"
                    rows={4}
                  />
                </div>

                <div className="flex justify-end space-x-3 mt-6">
                  <button
                    onClick={() => setShowNewCampaign(false)}
                    className="px-4 py-2 border border-gray-300 rounded-xl text-gray-700 hover:bg-gray-50 transition-all"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={createCampaign}
                    className="px-4 py-2 bg-primary text-white rounded-xl hover:bg-primary-light transition-all shadow-sm"
                  >
                    Create Campaign
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-20">
          {campaigns.map((campaign) => (
            <div 
              key={campaign.id} 
              className={`bg-white rounded-2xl shadow-xl border transition-all backdrop-blur-xl ${
                campaign.id === user?.active_campaign_id 
                  ? 'border-primary ring-1 ring-primary/20' 
                  : 'border-gray-100 hover:border-gray-200'
              }`}
            >
              <div className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">{campaign.title}</h3>
                    <p className="text-sm text-gray-500 mt-1">
                      Created {new Date(campaign.created_at || '').toLocaleDateString()}
                    </p>
                  </div>
                  <button
                    onClick={() => setCampaignToDelete(campaign)}
                    className="text-gray-400 hover:text-red-500 transition-colors"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm font-medium text-gray-700">Target Audience/Niche</h4>
                    <p className="mt-1 text-sm text-gray-600 line-clamp-2">{campaign.niche}</p>
                  </div>

                  <div className="flex justify-center">
                    <QRCode
                      value={getCaptureUrl(campaign.id)}
                      size={150}
                    />
                  </div>

                  <div className="flex justify-between items-center">
                    <button
                      onClick={() => downloadLeads(campaign.id)}
                      className="flex items-center px-3 py-1.5 bg-gray-50 text-gray-700 rounded-lg hover:bg-gray-100 transition-all text-sm"
                    >
                      <Download className="w-4 h-4 mr-1" />
                      Download Leads
                    </button>
                    
                    <button
                      onClick={() => campaign.id === user?.active_campaign_id ? setPreviewCampaign(campaign) : setActiveCampaign(campaign.id)}
                      className={`px-3 py-1.5 rounded-lg text-sm transition-all ${
                        campaign.id === user?.active_campaign_id
                          ? 'bg-primary text-white hover:bg-primary-light'
                          : 'border border-primary text-primary hover:bg-primary/5'
                      }`}
                    >
                      {campaign.id === user?.active_campaign_id ? 'Preview Campaign' : 'Make Active'}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-2">
          <Footer />
        </div>
      </div>

      {previewCampaign && (
        <CampaignPreviewModal
          campaign={previewCampaign}
          onClose={() => setPreviewCampaign(null)}
        />
      )}

      {campaignToDelete && (
        <DeleteCampaignModal
          campaignTitle={campaignToDelete.title}
          onConfirm={() => deleteCampaign(campaignToDelete)}
          onCancel={() => setCampaignToDelete(null)}
        />
      )}
    </div>
  );
}