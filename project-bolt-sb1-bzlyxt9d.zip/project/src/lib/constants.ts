// Force the use of the production URL for APP_URL
export const APP_URL = 'https://app.fortunecookieleads.com';
