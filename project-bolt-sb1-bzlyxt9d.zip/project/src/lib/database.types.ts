export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          username: string | null
          active_campaign_id: string | null
          branding: Json | null
          created_at: string | null
          updated_at: string | null
          onboarding_completed: boolean | null
        }
        Insert: {
          id: string
          username?: string | null
          active_campaign_id?: string | null
          branding?: Json | null
          created_at?: string | null
          updated_at?: string | null
          onboarding_completed?: boolean | null
        }
        Update: {
          id?: string
          username?: string | null
          active_campaign_id?: string | null
          branding?: Json | null
          created_at?: string | null
          updated_at?: string | null
          onboarding_completed?: boolean | null
        }
      }
      campaigns: {
        Row: {
          id: string
          user_id: string | null
          title: string
          niche: string
          welcome_message: string | null
          branding: Json | null
          created_at: string | null
          updated_at: string | null
        }
        Insert: {
          id?: string
          user_id?: string | null
          title: string
          niche: string
          welcome_message?: string | null
          branding?: Json | null
          created_at?: string | null
          updated_at?: string | null
        }
        Update: {
          id?: string
          user_id?: string | null
          title?: string
          niche?: string
          welcome_message?: string | null
          branding?: Json | null
          created_at?: string | null
          updated_at?: string | null
        }
      }
      leads: {
        Row: {
          id: string
          campaign_id: string | null
          name: string
          email: string
          fortune: string
          created_at: string | null
        }
        Insert: {
          id?: string
          campaign_id?: string | null
          name: string
          email: string
          fortune: string
          created_at?: string | null
        }
        Update: {
          id?: string
          campaign_id?: string | null
          name?: string
          email?: string
          fortune?: string
          created_at?: string | null
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {}
  }
}