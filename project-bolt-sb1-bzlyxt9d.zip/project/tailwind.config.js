/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#03376e',
          light: '#0a4d8c',
          dark: '#02284f'
        }
      },
      boxShadow: {
        'inner-glow': 'inset 0 2px 4px 0 rgba(255, 255, 255, 0.05)',
      },
      borderRadius: {
        'input': '4px',
      }
    },
  },
  plugins: [],
};