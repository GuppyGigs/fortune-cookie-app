/*
  # Initial Schema Setup

  1. Tables
    - users
      - Extended auth.users with subscription and branding info
    - campaigns
      - Stores campaign information and settings
    - leads
      - Stores captured lead information
  
  2. Security
    - Enable RLS on all tables
    - Add policies for user access
*/

-- Create custom types
CREATE TYPE subscription_tier AS ENUM ('free', 'pro', 'enterprise');

-- Create a table for public profiles
CREATE TABLE IF NOT EXISTS public.profiles (
  id uuid REFERENCES auth.users ON DELETE CASCADE,
  username text UNIQUE,
  subscription_tier subscription_tier DEFAULT 'free',
  active_campaign_id uuid,
  branding jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  PRIMARY KEY (id)
);

-- Create campaigns table
CREATE TABLE IF NOT EXISTS public.campaigns (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES auth.users ON DELETE CASCADE,
  title text NOT NULL,
  niche text NOT NULL,
  welcome_message text,
  branding jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create leads table
CREATE TABLE IF NOT EXISTS public.leads (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  campaign_id uuid REFERENCES public.campaigns ON DELETE CASCADE,
  name text NOT NULL,
  email text NOT NULL,
  fortune text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.campaigns ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.leads ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Users can view own profile"
  ON public.profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON public.profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can view own campaigns"
  ON public.campaigns FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own campaigns"
  ON public.campaigns FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own campaigns"
  ON public.campaigns FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own campaigns"
  ON public.campaigns FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can view leads from own campaigns"
  ON public.leads FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.campaigns
      WHERE id = leads.campaign_id
      AND user_id = auth.uid()
    )
  );

CREATE POLICY "Anyone can insert leads"
  ON public.leads FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

-- Functions
CREATE OR REPLACE FUNCTION check_campaign_limit()
RETURNS TRIGGER AS $$
DECLARE
  campaign_count INT;
  max_campaigns INT;
  user_tier subscription_tier;
BEGIN
  -- Get user's subscription tier
  SELECT subscription_tier INTO user_tier
  FROM public.profiles
  WHERE id = NEW.user_id;

  -- Set max campaigns based on tier
  CASE user_tier
    WHEN 'free' THEN max_campaigns := 1;
    WHEN 'pro' THEN max_campaigns := 3;
    WHEN 'enterprise' THEN max_campaigns := 20;
    ELSE max_campaigns := 0;
  END CASE;

  -- Count existing campaigns
  SELECT COUNT(*) INTO campaign_count
  FROM public.campaigns
  WHERE user_id = NEW.user_id;

  -- Check if limit would be exceeded
  IF campaign_count >= max_campaigns THEN
    RAISE EXCEPTION 'Campaign limit reached for subscription tier';
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for campaign limit
CREATE TRIGGER check_campaign_limit_trigger
  BEFORE INSERT ON public.campaigns
  FOR EACH ROW
  EXECUTE FUNCTION check_campaign_limit();