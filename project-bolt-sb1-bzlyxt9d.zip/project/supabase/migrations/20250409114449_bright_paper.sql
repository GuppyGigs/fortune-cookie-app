/*
  # Fix Campaign User Relationship

  1. Changes
    - Remove incorrect foreign key if it exists
    - Add correct foreign key relationship between campaigns.user_id and auth.users.id
    - Update the join query to use the correct relationship

  2. Security
    - No changes to RLS policies
    - Existing security remains intact
*/

-- First, safely remove any existing incorrect foreign key
DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 
    FROM information_schema.table_constraints 
    WHERE constraint_name = 'campaigns_user_id_fkey'
  ) THEN
    ALTER TABLE campaigns DROP CONSTRAINT campaigns_user_id_fkey;
  END IF;
END $$;

-- Add the correct foreign key relationship
ALTER TABLE campaigns
ADD CONSTRAINT campaigns_user_id_fkey
FOREIGN KEY (user_id) 
REFERENCES auth.users(id)
ON DELETE CASCADE;