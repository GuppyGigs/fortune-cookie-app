/*
  # Update storage policies for brand assets bucket

  1. Security Changes
    - Drop existing policies to avoid conflicts
    - Recreate policies with proper permissions
    - Ensures consistent policy setup
*/

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Anyone can view brand assets" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can upload brand assets" ON storage.objects;
DROP POLICY IF EXISTS "Users can update own brand assets" ON storage.objects;
DROP POLICY IF EXISTS "Users can delete own brand assets" ON storage.objects;

-- Set up storage policies
CREATE POLICY "Anyone can view brand assets"
  ON storage.objects FOR SELECT
  USING ( bucket_id = 'brand-assets' );

CREATE POLICY "Authenticated users can upload brand assets"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'brand-assets'
    AND auth.uid() = owner
  );

CREATE POLICY "Users can update own brand assets"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING ( bucket_id = 'brand-assets' AND auth.uid() = owner )
  WITH CHECK ( bucket_id = 'brand-assets' AND auth.uid() = owner );

CREATE POLICY "Users can delete own brand assets"
  ON storage.objects FOR DELETE
  TO authenticated
  USING ( bucket_id = 'brand-assets' AND auth.uid() = owner );