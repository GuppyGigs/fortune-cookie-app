/*
  # Add onboarding flag to profiles

  1. Changes
    - Add onboarding_completed column to profiles table
    - Set default value to false
    - Add storage bucket for brand assets
*/

-- Add onboarding_completed column
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS onboarding_completed BOOLEAN DEFAULT false;

-- Create storage bucket for brand assets if it doesn't exist
INSERT INTO storage.buckets (id, name)
VALUES ('brand-assets', 'brand-assets')
ON CONFLICT (id) DO NOTHING;

-- Set up storage policy to allow authenticated users to upload
CREATE POLICY "Users can upload brand assets"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'brand-assets');

-- Allow authenticated users to read brand assets
CREATE POLICY "Anyone can view brand assets"
ON storage.objects FOR SELECT
TO authenticated, anon
USING (bucket_id = 'brand-assets');