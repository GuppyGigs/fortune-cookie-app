/*
  # Add onboarding flag to profiles table

  1. Changes
    - Add onboarding_completed flag to profiles table
    - Update existing profiles to have onboarding_completed set to true
*/

-- Add onboarding_completed column if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' 
    AND column_name = 'onboarding_completed'
  ) THEN
    ALTER TABLE profiles ADD COLUMN onboarding_completed boolean DEFAULT false;
  END IF;
END $$;

-- Update existing profiles to have onboarding_completed set to true
UPDATE profiles 
SET onboarding_completed = true 
WHERE branding IS NOT NULL;