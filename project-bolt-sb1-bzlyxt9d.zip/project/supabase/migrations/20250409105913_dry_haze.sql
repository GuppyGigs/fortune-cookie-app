/*
  # Remove subscription tiers and set fixed campaign limit

  1. Changes
    - Remove subscription_tier enum type
    - Remove subscription_tier column from profiles
    - Update campaign limit function to allow 2 campaigns per user
    - Update existing data
*/

-- Drop subscription_tier column from profiles
ALTER TABLE profiles DROP COLUMN IF EXISTS subscription_tier;

-- Drop the enum type (will fail if other tables use it, which is fine)
DROP TYPE IF EXISTS subscription_tier;

-- Update the campaign limit function
CREATE OR REPLACE FUNCTION check_campaign_limit()
RETURNS TRIGGER AS $$
DECLARE
  campaign_count INT;
BEGIN
  -- Count existing campaigns
  SELECT COUNT(*) INTO campaign_count
  FROM public.campaigns
  WHERE user_id = NEW.user_id;

  -- Check if limit would be exceeded (allow 2 campaigns)
  IF campaign_count >= 2 THEN
    RAISE EXCEPTION 'Maximum campaign limit (2) reached';
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;