import { createClient } from 'npm:@supabase/supabase-js@2.39.7';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { niche } = await req.json();

    if (!niche) {
      throw new Error('Niche is required');
    }

    // Parse and analyze the niche to identify key themes
    const keywords = niche.toLowerCase().split(/\s+/);
    const themes = {
      leadership: keywords.some(w => /lead|manage|direct|guide/.test(w)),
      health: keywords.some(w => /health|wellness|care|patient/.test(w)),
      business: keywords.some(w => /business|entrepreneur|professional|career/.test(w)),
      personal: keywords.some(w => /personal|growth|development|life/.test(w))
    };

    // Select appropriate fortune templates based on themes
    let fortuneTemplates = [];
    
    if (themes.leadership) {
      fortuneTemplates = [
        "Your leadership will inspire positive change {timeframe}",
        "A team will rally behind your vision {timeframe}",
        "Your guidance will help others find their path {timeframe}",
        "Your decisive action will create new opportunities {timeframe}"
      ];
    } else if (themes.health) {
      fortuneTemplates = [
        "Your dedication to wellness will bring unexpected rewards {timeframe}",
        "Your compassionate care will touch many lives {timeframe}",
        "A breakthrough in healing awaits your discovery {timeframe}",
        "Your holistic approach will lead to remarkable outcomes {timeframe}"
      ];
    } else if (themes.business) {
      fortuneTemplates = [
        "A profitable venture will present itself {timeframe}",
        "Your innovative thinking will lead to success {timeframe}",
        "A valuable partnership will emerge {timeframe}",
        "Your strategic vision will open new doors {timeframe}"
      ];
    } else {
      fortuneTemplates = [
        "Your unique path will lead to fulfillment {timeframe}",
        "An unexpected opportunity will bring joy {timeframe}",
        "Your authentic self will attract success {timeframe}",
        "A positive change will transform your journey {timeframe}"
      ];
    }

    const timeframes = [
      "in the coming weeks",
      "when the moon is full",
      "as spring approaches",
      "when you least expect it",
      "as the seasons change",
      "before the year ends"
    ];

    // Generate the fortune
    const template = fortuneTemplates[Math.floor(Math.random() * fortuneTemplates.length)];
    const timeframe = timeframes[Math.floor(Math.random() * timeframes.length)];
    const fortune = template.replace('{timeframe}', timeframe);

    return new Response(
      JSON.stringify({ fortune }),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 400,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});